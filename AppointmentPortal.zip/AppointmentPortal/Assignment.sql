CREATE DATABASE AppointmentDB;
USE AppointmentDB;
CREATE TABLE Doctors (DoctorId INT IDENTITY(1,1) PRIMARY KEY,Name NVARCHAR(100) NOT NULL,Specialization NVARCHAR(100) NOT NULL,Fee DECIMAL(10,2) NOT NULL);
INSERT INTO Doctors (Name, Specialization, Fee) VALUES
('Dr. Asha Verma', 'General Physician', 300),
('Dr. Rohit Sharma', 'Dermatologist', 500),
('Dr. Meera Joshi', 'Pediatrician', 400),
('Dr. Amit Kumar', 'Orthopedics', 600);
select*from Doctors;
CREATE TABLE Appointments (
    AppointmentId INT IDENTITY(1,1) PRIMARY KEY,
    PatientName NVARCHAR(100) NOT NULL,
    DoctorId INT NOT NULL FOREIGN KEY REFERENCES Doctors(DoctorId),
    AppointmentDate DATE NOT NULL,
    AppointmentTime TIME NOT NULL,
    CreatedAt DATETIME NOT NULL DEFAULT(GETDATE())
);
select*from Appointments;