﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace AppointmentPortal
{
    public partial class ViewAppointments : System.Web.UI.Page
    {
        private string connStr = ConfigurationManager.ConnectionStrings["AppointmentConn"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadAppointments();
            }
        }

        private void LoadAppointments()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connStr))
                {
                    string sql = @"SELECT a.PatientName,
        d.Name AS DoctorName,
        d.Specialization,
        CONVERT(VARCHAR(10), a.AppointmentDate, 23) AS AppointmentDate,           -- yyyy-mm-dd
        CONVERT(VARCHAR(5), a.AppointmentTime, 108) AS AppointmentTime,           -- HH:MM
        CONVERT(VARCHAR(16), a.CreatedAt, 120) AS CreatedAt                       -- yyyy-mm-dd HH:MM
    FROM Appointments a
    LEFT JOIN Doctors d ON a.DoctorId = d.DoctorId
    ORDER BY a.AppointmentDate DESC, a.AppointmentTime DESC";
                    SqlDataAdapter da = new SqlDataAdapter(sql, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    if (dt.Rows.Count == 0)
                    {
                        lblInfo.Text = "No appointments found.";
                    }
                    else
                    {
                        lblInfo.Text = "";
                    }

                    gvAppointments.DataSource = dt;
                    gvAppointments.DataBind();
                }
            }
            catch (Exception ex)
            {
                // show friendly error and optionally log
                lblInfo.Text = "Error loading appointments: " + ex.Message;
            }
        }
    }
}
