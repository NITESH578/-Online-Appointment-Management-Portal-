﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace AppointmentPortal
{
    public partial class DoctorsList : System.Web.UI.Page
    {
        private string connStr = ConfigurationManager.ConnectionStrings["AppointmentConn"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadDoctors();
            }
        }

        private void LoadDoctors()
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                string query = "SELECT Name, Specialization, Fee FROM Doctors";
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                gvDoctors.DataSource = dt;
                gvDoctors.DataBind();
            }
        }
    }
}
