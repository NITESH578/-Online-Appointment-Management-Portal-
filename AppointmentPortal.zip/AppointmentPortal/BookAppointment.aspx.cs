﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace AppointmentPortal
{
    public partial class BookAppointment : System.Web.UI.Page
    {
        private string connStr = ConfigurationManager.ConnectionStrings["AppointmentConn"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadDoctors();
            }
        }

        private void LoadDoctors()
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                string query = "SELECT DoctorId, Name FROM Doctors";
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);

                ddlDoctors.DataSource = dt;
                ddlDoctors.DataTextField = "Name";
                ddlDoctors.DataValueField = "DoctorId";
                ddlDoctors.DataBind();
                ddlDoctors.Items.Insert(0, new System.Web.UI.WebControls.ListItem("--Select--", ""));
            }
        }

        protected void btnBook_Click(object sender, EventArgs e)
        {
            if (!Page.IsValid) return;

            string patientName = txtPatientName.Text.Trim();
            if (string.IsNullOrEmpty(patientName))
            {
                lblMessage.Text = "Patient name required";
                lblMessage.ForeColor = System.Drawing.Color.Red;
                return;
            }

            if (string.IsNullOrEmpty(ddlDoctors.SelectedValue))
            {
                lblMessage.Text = "Select a doctor";
                lblMessage.ForeColor = System.Drawing.Color.Red;
                return;
            }

            if (!DateTime.TryParse(txtDate.Text, out DateTime date) ||
                !TimeSpan.TryParse(txtTime.Text, out TimeSpan time))
            {
                lblMessage.Text = "Invalid date or time.";
                lblMessage.ForeColor = System.Drawing.Color.Red;
                return;
            }

            DateTime appointmentDateTime = date.Date + time;
            if (appointmentDateTime < DateTime.Now)
            {
                lblMessage.Text = "Cannot book an appointment in the past.";
                lblMessage.ForeColor = System.Drawing.Color.Red;
                return;
            }

            int doctorId = int.Parse(ddlDoctors.SelectedValue);

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();

                string checkQuery = @"SELECT COUNT(*) FROM Appointments
                                      WHERE DoctorId = @DoctorId
                                        AND AppointmentDate = @Date
                                        AND AppointmentTime = @Time";

                using (SqlCommand cmd = new SqlCommand(checkQuery, conn))
                {
                    cmd.Parameters.AddWithValue("@DoctorId", doctorId);
                    cmd.Parameters.AddWithValue("@Date", date.Date);
                    cmd.Parameters.AddWithValue("@Time", time);

                    int exists = (int)cmd.ExecuteScalar();
                    if (exists > 0)
                    {
                        lblMessage.Text = "This slot is already booked for this doctor.";
                        lblMessage.ForeColor = System.Drawing.Color.Red;
                        return;
                    }
                }

                string insertQuery = @"INSERT INTO Appointments (PatientName, DoctorId, AppointmentDate, AppointmentTime)
                                       VALUES (@PatientName, @DoctorId, @Date, @Time)";

                using (SqlCommand cmd = new SqlCommand(insertQuery, conn))
                {
                    cmd.Parameters.AddWithValue("@PatientName", patientName);
                    cmd.Parameters.AddWithValue("@DoctorId", doctorId);
                    cmd.Parameters.AddWithValue("@Date", date.Date);
                    cmd.Parameters.AddWithValue("@Time", time);

                    cmd.ExecuteNonQuery();
                }
            }

            lblMessage.Text = "Appointment booked successfully!";
            lblMessage.ForeColor = System.Drawing.Color.Green;

            txtPatientName.Text = "";
            txtDate.Text = "";
            txtTime.Text = "";
            ddlDoctors.SelectedIndex = 0;
        }
    }
}
